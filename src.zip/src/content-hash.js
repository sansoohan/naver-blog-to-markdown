const crypto = require("crypto");

function getPostBody(root) {
  /*
   * [해시 대상 - 게시글 본문]
   *
   * 콘텐츠 해시는 게시글의 실제 본문만 대상으로 한다.
   * 제목, 작성자, 작성일, 카테고리, 공유, 신고, 공감, 댓글, 태그 등
   * 게시글 주변의 네이버 UI는 처음부터 해시 대상에 포함하지 않는다.
   *
   * 현대 에디터:
   *   .se-main-container
   *
   * 초기 SmartEditor 3:
   *   .__se_component_area
   *
   * 구형 에디터:
   *   #postViewArea
   *
   * 중요:
   * 본문 선택자를 찾지 못했다고 root 전체를 fallback으로 사용하지 말 것.
   * root 전체에는 게시글과 관계없는 네이버 UI와 동적 값이 포함될 수 있으므로
   * 잘못된 해시를 만드는 것보다 명시적으로 실패하는 편이 안전하다.
   */

  /*
   * 초기 SmartEditor 3.
   *
   * getPostRoot() 단계에서 .se_doc_contents_start 다음의
   * .__se_component_area를 이미 본문 root로 선택한다.
   */
  if (root.is(".__se_component_area")) return root;

  /*
   * 현대 SmartEditor 3·4.
   */
  if (root.is(".se-main-container")) return root;

  const mainContainer = root.find(".se-main-container").first();

  if (mainContainer.length) return mainContainer;

  /*
   * 초기 SmartEditor 3의 상위 root가 전달된 경우.
   */
  const se3ContentsStart = root.find(".se_doc_contents_start").first();

  if (se3ContentsStart.length) {
    const se3Body = se3ContentsStart.nextAll(".__se_component_area").first();

    if (se3Body.length) return se3Body;
  }

  /*
   * 구형 SmartEditor 1·2.
   */
  if (root.is("#postViewArea")) return root;

  const postViewArea = root.find("#postViewArea").first();

  if (postViewArea.length) return postViewArea;

  /*
   * 일부 구형 게시글에서는 전달받은 root 자체가 .post-view일 수 있다.
   */
  if (root.is(".post-view")) return root;

  const postView = root.find(".post-view").first();

  if (postView.length) return postView;

  throw new Error("콘텐츠 해시를 생성할 게시글 본문을 찾을 수 없습니다.");
}

function createContentHash(root) {
  const postBody = getPostBody(root);
  const clone = postBody.clone();

  /*
   * [해시 제외 - HTML id 속성]
   *
   * 네이버가 페이지 렌더링 과정에서 동적으로 생성하는 id가 포함될 수 있다.
   * 같은 게시글을 다시 불러와도 값이 달라질 수 있으므로 해시에서 제외한다.
   *
   * 중요:
   * 이 처리를 삭제하면 실제 게시글 내용이 바뀌지 않아도 동적 id 때문에 해시가 달라질 수 있다.
   * 반대로 id 자체가 실제 게시글 내용인지 확인하지 않고 이 제외 범위를 더 넓히지 말 것.
   */
  clone.find("*").each((_, element) => {
    const $el = clone.find(element);
    const attrs = element.attribs || {};

    for (const name of Object.keys(attrs)) {
      if (name === "id") {
        $el.removeAttr(name);
        continue;
      }

      /*
       * [해시 제외 - 빈 class 속성]
       *
       * 네이버가 동일한 요소를 렌더링하면서 class=""를 추가하거나
       * class 속성 자체를 생략하는 경우가 있다.
       *
       * 실제 확인된 차이:
       *
       *   <img ... class="">
       *   <img ...>
       *
       * 실제 클래스가 없는 동일한 요소이므로 빈 class 속성은 해시에서 제외한다.
       *
       * 중요:
       * 다른 빈 속성은 존재 여부 자체가 의미를 가질 수 있으므로 제거하지 않는다.
       */
      if (["class", "style", "align"].includes(name) && !String(attrs[name] || "").trim()) {
        $el.removeAttr(name);
        continue;
      }

      /*
       * [해시 제외 - data-* 속성]
       *
       * 네이버 내부 동작과 렌더링 상태에 사용되는 data-* 속성은 실행 시 달라질 수 있으므로 제외한다.
       *
       * data-linktype은 링크 종류를 나타내는 콘텐츠 구조 정보이므로 예외적으로 유지한다.
       *
       * 중요:
       * data-*를 무조건 제거하는 현재 규칙을 수정할 때는 실제 콘텐츠 식별정보가 들어가는지 먼저 확인할 것.
       * 유지해야 할 data-*가 발견되면 data-linktype처럼 반드시 예외 목록에 추가할 것.
       */
      if (name.startsWith("data-") && name !== "data-linktype") $el.removeAttr(name);
    }
  });

  /*
   * [해시 제외 - script / style]
   *
   * 실행용 JavaScript와 스타일 정의는 게시글의 실제 텍스트/미디어 내용과 별개이며
   * 네이버가 내부 코드를 변경하면 게시글을 수정하지 않아도 내용이 달라질 수 있으므로 제외한다.
   *
   * 중요:
   * 이 처리를 삭제하면 네이버 내부 script/style 변경만으로 게시글 해시가 달라질 수 있다.
   */
  clone.find("script, style").remove();

  /*
   * [해시 제외 - 현대 에디터 이미지 / 동영상 / oEmbed 컴포넌트]
   *
   * 현대 네이버 에디터의 미디어 컴포넌트는 페이지를 불러오는 시점의 네트워크 상태와
   * JavaScript 실행 상태에 따라 같은 게시글에서도 서로 다른 HTML이 생성될 수 있다.
   *
   * 실제 확인된 차이:
   *
   *   이미지:
   *     정상 로딩 -> <img src="...">
   *     로딩 실패 -> "존재하지 않는 이미지입니다."
   *
   *   동영상:
   *     정상 로딩 -> __se-component, se-media-meta 등의 DOM 생성
   *     로딩 전   -> 빈 .se-module-video
   *
   *   oEmbed:
   *     정상 로딩 -> iframe 등의 실제 임베드 DOM 생성
   *     로딩 전   -> se-is-progress 등의 로딩 상태 DOM
   *
   * 일부 로딩 실패 상태에서는 실제 미디어 URL이나 식별정보 자체가 DOM에 존재하지 않으므로
   * 런타임 DOM만 선택적으로 제거해서 두 상태를 항상 동일하게 만드는 것이 불가능하다.
   *
   * 따라서 이미지, 동영상, oEmbed 컴포넌트 전체를 해시에서 제외한다.
   *
   * 중요:
   * 이 규칙 때문에 이미지/동영상/oEmbed만 교체하고 다른 본문 내용은 전혀 수정하지 않은 경우
   * 콘텐츠 해시는 변경되지 않는다.
   *
   * 대신 외부 리소스의 일시적인 로딩 성공/실패만으로 게시글이 수정된 것으로 판단되는 문제를 방지한다.
   */
  clone.find(".se-component.se-image, .se-component.se-video, .se-component.se-oembed").remove();

  /*
   * [해시 정규화 - 구형 네이버 동영상 플레이어]
   *
   * 구형 게시글의 ._naverVideo 내부에는 페이지를 불러올 때마다 새로 생성되는
   * 플레이어 UUID, SVG ID 등 대량의 런타임 DOM이 포함된다.
   *
   * 실제 동영상 식별자인 vid는 유지하고 플레이어 DOM 전체를 고정된 형태로 정규화한다.
   *
   * 중요:
   * ._naverVideo를 단순히 삭제하지 말 것.
   * 실제 동영상이 교체되어 vid가 변경되면 해시도 변경되어야 한다.
   */
  clone.find("._naverVideo").each((_, element) => {
    const $el = clone.find(element);
    const vid = $el.attr("vid") || "";
    const parent = $el.parent();

    $el.replaceWith(`<div class="_naverVideo" vid="${vid}"></div>`);

    if (parent.is("p") && !parent.text().trim()) parent.replaceWith(parent.contents());
  });

  clone.find("._naverVideo").each((_, element) => {
    const $el = clone.find(element);
    const prev = $el.prev();
    const next = $el.next();

    if (prev.is("p") && !prev.html().trim()) prev.remove();
    if (next.is("p") && !next.html().trim()) next.remove();
  });

  /*
   * [해시 제외 - 네이버 플레이어 플러그인 런타임 ID]
   *
   * 네이버 동영상/플레이어 주변 DOM에 splugin-id="<숫자>"가 생성될 수 있으며
   * 같은 게시글에서도 페이지를 다시 열 때 값이 달라지는 것이 확인되었다.
   *
   * 예:
   *   splugin-id="5539367842"
   *   splugin-id="2724968757"
   *
   * 중요:
   * 게시글 내용과 관계없는 런타임 식별자이므로 이 제거 처리를 삭제하지 말 것.
   */
  clone.find("[splugin-id]").removeAttr("splugin-id");

  /*
   * [해시 제외 - 구형 이미지 런타임 클래스]
   *
   * 구형 네이버 게시글의 이미지에는 페이지 렌더링 상태에 따라
   * egjs-visible 클래스가 추가되거나 존재하지 않을 수 있다.
   *
   * 실제 확인된 차이:
   *
   *   _photoImage
   *   _photoImage egjs-visible
   *
   * 게시글 내용과 관계없는 런타임 상태 클래스이므로 해시에서 제외한다.
   *
   * 중요:
   * _photoImage 자체는 실제 이미지 요소를 식별하는 클래스이므로 유지한다.
   */
  clone.find(".egjs-visible").removeClass("egjs-visible");

  /*
   * [해시 제외 - 첨부파일 다운로드 URL]
   *
   * 네이버 첨부파일의 .se-file-save-button href에는 같은 파일이어도 페이지를 다시 불러올 때
   * 변경될 수 있는 동적 다운로드 식별자가 포함된다.
   *
   * 파일명, 확장자 및 첨부파일 컴포넌트 자체는 유지하고 다운로드 href만 해시에서 제외한다.
   *
   * 중요:
   * .se-component.se-file 전체를 제거하지 말 것.
   * 실제 첨부파일이 추가/삭제되거나 파일명이 변경되면 해시가 달라져야 한다.
   */
  clone.find(".se-component.se-file a.se-file-save-button").removeAttr("href");

  /*
   * [해시 제외 - OG 링크 썸네일]
   *
   * 네이버 OG 링크 미리보기의 썸네일은 외부 이미지 로딩 상태에 따라
   * 같은 게시글에서도 DOM 전체가 생성되거나 존재하지 않을 수 있다.
   *
   * 실제 확인된 차이:
   *
   *   정상 로딩:
   *     <a class="se-oglink-thumbnail ...">
   *       <img class="se-oglink-thumbnail-resource ...">
   *     </a>
   *
   *   로딩 실패/미완료:
   *     .se-oglink-thumbnail 자체가 존재하지 않음
   *
   * OG 링크의 실제 href, 제목, 요약, URL 정보는 .se-oglink-info에 별도로
   * 존재하므로 썸네일 영역만 해시에서 제외한다.
   *
   * 중요:
   * .se-component.se-oglink 전체를 제거하지 말 것.
   * 실제 링크 주소나 제목 등의 콘텐츠가 변경되면 해시도 변경되어야 한다.
   */
  clone.find(".se-oglink-thumbnail").remove();

  /*
   * [해시 제외 - OG 링크 런타임 클래스]
   *
   * 네이버 OG 링크 컴포넌트에는 페이지를 불러오는 시점의 JavaScript 실행 상태에 따라
   * __se-component 클래스가 추가되거나 존재하지 않을 수 있다.
   *
   * 실제 확인된 차이:
   *
   *   se-component se-oglink se-l-text
   *   se-component se-oglink se-l-text __se-component
   *
   * OG 링크의 실제 href, 제목, 요약, URL 정보는 동일하므로
   * __se-component 클래스만 해시에서 제외한다.
   *
   * 중요:
   * .se-component.se-oglink 전체를 제거하지 말 것.
   * 실제 링크 주소나 제목 등의 콘텐츠가 변경되면 해시도 변경되어야 한다.
   */
  clone.find(".se-component.se-oglink.__se-component").removeClass("__se-component");

  /*
   * [해시 제외 - 네이버 이미지 렌더링 옵션]
   *
   * 네이버 이미지 URL의 type query parameter는 같은 원본 이미지에서도
   * 페이지 로딩 상태에 따라 다른 값이 사용될 수 있다.
   *
   * 실제 확인된 차이:
   *   ?type=w3
   *   ?type=w80_blur
   *
   * 원본 이미지 경로는 그대로 유지하고 type parameter만 제거한다.
   *
   * 중요:
   * src 전체를 제거하지 말 것.
   * 실제 이미지 파일이 변경되면 해시도 변경되어야 한다.
   */
  clone.find("img[src]").each((_, element) => {
    const $el = clone.find(element);
    const src = $el.attr("src");

    if (!src) return;

    try {
      const url = new URL(src, "https://blog.naver.com");

      if (/\.pstatic\.net$/i.test(url.hostname)) {
        url.searchParams.delete("type");
        $el.attr("src", url.toString());
      }
    } catch {}
  });

  /*
   * [해시 제외 - URL의 일회성/동적 query parameter]
   *
   * 링크 자체는 실제 콘텐츠이므로 href 전체를 제거하지 않는다.
   * 대신 요청 시점이나 세션에 따라 달라질 수 있는 아래 query parameter의 값만 제거한다.
   *
   *   hashKey
   *   timestamp
   *   ts
   *   t
   *   rnd
   *   random
   *   nonce
   *
   * 중요:
   * URL 전체를 제거하지 말 것.
   * 실제 링크 주소가 변경된 경우에는 해시도 변경되어야 한다.
   *
   * 새로운 query parameter를 여기에 추가할 때도 실제 콘텐츠와 관계없는 동적 값인지 확인할 것.
   */
  clone.find("a").each((_, element) => {
    const $el = clone.find(element);
    const href = $el.attr("href");

    if (!href) return;

    try {
      const url = new URL(href, "https://blog.naver.com");

      for (const key of [...url.searchParams.keys()]) {
        if (/^(hashKey|timestamp|ts|t|rnd|random|nonce)$/i.test(key)) url.searchParams.delete(key);
      }

      $el.attr("href", url.toString());
    } catch {}
  });

  /*
   * [해시 제외 - 구형 네이버 첨부파일 다운로드 URL 해시]
   *
   * 구형 게시글의 download.blog.naver.com/open/ URL에는 같은 첨부파일이어도
   * 페이지를 다시 불러올 때 변경될 수 있는 동적 해시가 경로에 포함된다.
   *
   * 실제 확인된 차이:
   *
   *   https://download.blog.naver.com/open/<동적 해시>/<고정 경로>/<파일명>
   *
   * 첨부파일의 나머지 경로와 파일명은 유지하고 동적 해시 부분만 고정된 값으로 정규화한다.
   *
   * 중요:
   * URL 전체를 제거하지 말 것.
   * 실제 첨부파일 경로나 파일명이 변경되면 해시도 변경되어야 한다.
   */
  clone.find("a[href]").each((_, element) => {
    const $el = clone.find(element);
    const href = $el.attr("href");

    if (!href) return;

    const normalizedHref = href.replace(
      /(https:\/\/download\.blog\.naver\.com\/open\/)[^/]+\//i,
      "$1{HASH}/"
    );

    if (normalizedHref !== href) $el.attr("href", normalizedHref);
  });

  /*
   * [해시 제외 - HTML 주석]
   *
   * HTML 주석은 화면에 표시되는 게시글 내용이 아니며 네이버 내부 처리에 의해 달라질 수 있으므로 제외한다.
   *
   * 중요:
   * 실제 게시글 내용 변경 감지에는 필요하지 않으므로 이 제거 처리를 유지할 것.
   */
  const html = (clone.html() || "")
    .replace(/<!--[\s\S]*?-->/g, "")

    /*
     * [해시 정규화 - 공백]
     *
     * HTML 직렬화나 렌더링 과정에서 의미 없는 공백/줄바꿈 차이가 생겨도
     * 동일한 게시글을 다른 내용으로 판단하지 않도록 연속 공백을 하나로 합친다.
     *
     * 중요:
     * 이것은 텍스트를 삭제하는 것이 아니라 HTML 소스상의 연속 공백 차이를 정규화하는 처리다.
     */
    .replace(/\s+/g, " ")
    .trim();

  const hash = crypto.createHash("sha256").update(html).digest("hex");

  return {hash, source: html};
}

module.exports = {
  createContentHash,
};