const cheerio = require("cheerio");
const TurndownService = require("turndown");

const { protectTextComponents } = require("./paragraph");
const { protectTables } = require("./table");
const { getLegacyTableCss } = require("./table/render");
const { protectQuotes } = require("./quote");
const { protectHorizontalLines, getHorizontalLineCss } = require("./horizontal-line");
const { protectCodeBlocks } = require("./code");
const { protectAttachments } = require("./attachment");
const { protectYouTube, protectNaverVideos } = require("./video");

function createStore() {
  let index = 0;
  const values = new Map();

  return {
    add(value) {
      const token = `NAVERPLACEHOLDER${String(++index).padStart(8, "0")}END`;
      values.set(token, String(value));
      return token;
    },

    restore(text) {
      let result = String(text);

      /*
       * 보호된 HTML 안에 다른 placeholder가 들어갈 수 있으므로
       * 변경이 없어질 때까지 반복해서 복구한다.
       */
      for (let pass = 0; pass <= values.size; pass++) {
        const previous = result;

        for (const [token, value] of values) result = result.split(token).join(value);
        if (result === previous) break;
      }

      return result;
    },
  };
}

/*
 * 이미지 뒤에 같은 줄의 링크가 붙어 있는 인라인 구조는
 * 다른 변환이 DOM을 분리하기 전에 HTML 그대로 보호한다.
 *
 * 예:
 * <img ...> <a ...>링크</a> | <a ...>링크</a><br>
 */
function protectInlineHtmlLinkGroups($, root, store) {
  const images = root.find("img").toArray();

  for (const element of images) {
    const image = $(element);

    if (!image.parent().length) continue;
    if (image.closest(".naver-protected,.naver-protected-inline").length) continue;

    let sibling = element.nextSibling;
    let hasLink = false;

    while (sibling) {
      const nodeName = String(sibling.name || sibling.tagName || sibling.nodeName || "").toLowerCase();

      if (sibling.nodeType === 1 && nodeName === "br") break;

      if (sibling.nodeType === 1 && nodeName === "a") {
        hasLink = true;
        break;
      }

      sibling = sibling.nextSibling;
    }

    if (!hasLink) continue;

    /*
     * 현재 img부터 <br> 직전까지를 하나의 HTML 인라인 조각으로 보호한다.
     */
    const nodes = [element];
    sibling = element.nextSibling;

    while (sibling) {
      const nodeName = String(sibling.name || sibling.tagName || sibling.nodeName || "").toLowerCase();

      if (sibling.nodeType === 1 && nodeName === "br") break;

      nodes.push(sibling);
      sibling = sibling.nextSibling;
    }

    const html = nodes.map(node => {
      if (node.nodeType === 3) return node.nodeValue || "";
      return $.html(node);
    }).join("");

    const token = store.add(html);

    /*
     * 첫 노드를 placeholder로 교체하고 나머지 노드는 제거한다.
     */
    image.replaceWith(`<span class="naver-protected-inline">${token}</span>`);

    for (let index = 1; index < nodes.length; index++) {
      $(nodes[index]).remove();
    }
  }
}

function createTurndown() {
  const turndown = new TurndownService({
    headingStyle: "atx",
    bulletListMarker: "-",
    codeBlockStyle: "fenced",
    emDelimiter: "*",
    strongDelimiter: "**",
  });

  turndown.addRule("protected", {
    filter(node) {
      return node.nodeName === "DIV" && node.classList.contains("naver-protected");
    },

    replacement(content, node) {
      return `\n\n${node.textContent}\n\n`;
    },
  });

  /*
   * 인라인 HTML 보호용 placeholder.
   * 블록 개행을 추가하지 않고 현재 위치 그대로 복구한다.
   */
  turndown.addRule("protectedInline", {
    filter(node) {
      return node.nodeName === "SPAN" && node.classList.contains("naver-protected-inline");
    },

    replacement(content, node) {
      return node.textContent;
    },
  });

  turndown.addRule("lineBreak", {
    filter: "br",

    replacement() {
      return "<br>";
    },
  });

  return turndown;
}

function getLegacyPostRoot($) {
  const content = $("#postViewArea,.se3_view,.post-view,.post-view > .view,.view").first();

  if (content.length) {
    const post = content.closest(".post._post_wrap,.post").first();
    if (post.length) return post;
    return content;
  }

  return $(".post._post_wrap,.post").first();
}

function getPostRoot($, editorVersion = 0) {
  /*
   * SmartEditor 1.x / 2.x:
   * make-html.js와 동일하게 글 전체 .post 래퍼를 사용한다.
   *
   * 구형 첨부파일은 .post 안에 삽입되므로 #postViewArea만 선택하면
   * Markdown 변환 시 첨부파일 영역이 빠질 수 있다.
   */
  if (editorVersion === 1 || editorVersion === 2) {
    const legacy = getLegacyPostRoot($);
    if (legacy.length) return legacy;
  }

  /*
   * SmartEditor 3.x 이상
   */
  const root = $(".se-main-container").first();
  if (root.length) return root;

  /*
   * fallback
   */
  const legacy = getLegacyPostRoot($);
  if (legacy.length) return legacy;

  throw new Error("original.html에서 본문 영역을 찾을 수 없습니다.");
}

function restoreEmptyLines(markdown) {
  return String(markdown).replace(/(?:NAVEREMPTYLINE\s*)+/g, match => {
    const count = (match.match(/NAVEREMPTYLINE/g) || []).length;
    return `${Array(count).fill("<br>").join("\n")}\n`;
  });
}

function normalizeBreakSpacing(markdown) {
  const lines = String(markdown).replace(/\r\n?/g, "\n").split("\n");
  const result = [];

  for (let index = 0; index < lines.length; index++) {
    const line = lines[index];

    if (line.trim().toLowerCase() !== "<br>") {
      result.push(line);
      continue;
    }

    let count = 1;

    while (index + count < lines.length && lines[index + count].trim().toLowerCase() === "<br>") count++;

    /*
     * 연속된 <br> 개수를 그대로 유지한다.
     */
    for (let offset = 0; offset < count; offset++) result.push("<br>");

    index += count - 1;

    /*
     * 마지막 <br> 아래에는 반드시 빈 줄을 하나 둔다.
     *
     * 이미지, 목록, 표, 코드블록, 인용문, 제목 등 다음 Markdown 블록이
     * HTML 블록에 먹히지 않고 정상적으로 해석되게 하기 위한 처리다.
     */
    const nextLine = lines[index + 1];

    if (nextLine !== undefined && nextLine.trim() !== "") result.push("");
  }

  return result.join("\n");
}

function cleanMarkdown(markdown) {
  return String(markdown)
    .replace(/\r\n/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n[ \t]+\n/g, "\n\n")
    .replace(/\n{4,}/g, "\n\n\n")
    .trim();
}

function escapeMarkdownAlt(value) {
  return String(value).replace(/\\/g, "\\\\").replace(/\[/g, "\\[").replace(/\]/g, "\\]");
}

function getImageRenderWidth(image) {
  /*
   * SmartEditor 3.x 이상:
   * 실제 이미지 표시 폭은 img가 아니라
   * 부모 .se-section-image의 max-width에 저장되는 경우가 있다.
   */
  const section = image.closest(".se-section-image");

  if (section.length) {
    const sectionStyle = section.attr("style") || "";
    const sectionMatch = sectionStyle.match(/max-width\s*:\s*(\d+(?:\.\d+)?)px/i);

    if (sectionMatch) {
      const width = Math.round(Number(sectionMatch[1]));

      if (width > 0) return width;
    }
  }

  /*
   * SmartEditor 1.x / 2.x:
   * style="width:550px" 형태로 실제 표시 폭이 저장되는 경우가 있다.
   */
  const style = image.attr("style") || "";
  const styleMatch = style.match(/(?:^|;)\s*width\s*:\s*(\d+(?:\.\d+)?)px/i);

  if (styleMatch) {
    const width = Math.round(Number(styleMatch[1]));

    if (width > 0) return width;
  }

  /*
   * 마지막으로 data-width 또는 width attribute를 사용한다.
   */
  const attributeWidth = Number(image.attr("data-width") || image.attr("width"));

  return Number.isFinite(attributeWidth) && attributeWidth > 0
    ? Math.round(attributeWidth)
    : 0;
}

function makeImageMarkdown(image) {
  const src = image.attr("src") || "";
  if (!src) return "";

  const alt = image.attr("alt") || "";
  const width = getImageRenderWidth(image);
  const isLegacyImage = image.hasClass("_photoImage");

  /*
   * 렌더링 폭이 저장되어 있으면 표준 Markdown 이미지 문법으로는
   * 크기를 표현할 수 없으므로 HTML img로 보존한다.
   *
   * 구형 네이버 이미지(_photoImage)는 각각 한 줄씩 표시한다.
   */
  if (width || isLegacyImage) {
    return `<img src="${escapeHtmlAttribute(src)}"`
      + `${alt ? ` alt="${escapeHtmlAttribute(alt)}"` : ""}`
      + ` style="${isLegacyImage ? "display:block;" : ""}${width ? `width:${width}px;` : ""}max-width:100%;height:auto;">`;
  }

  return `![${escapeMarkdownAlt(alt)}](${src})`;
}

function protectMissingImages($, root, store) {
  const components = root.find(".se-component.se-image").toArray();

  for (const element of components) {
    const component = $(element);
    const error = component.find(".se-state-error").first();

    if (!error.length) continue;

    /*
     * 누락된 이미지의 원래 표시 폭은 img나 se-state-error가 아니라
     * .se-section-image의 max-width에 남아 있다.
     */
    const section = component.find(".se-section-image").first();
    const style = section.attr("style") || "";
    const match = style.match(/max-width\s*:\s*(\d+(?:\.\d+)?)px/i);

    const width = match
      ? Math.round(Number(match[1]))
      : 580;

    const height = Math.round(width * 0.56);

    const html =
      `<div style="width:${width}px;height:${height}px;max-width:100%;background:#fff;`
      + `border:1px solid #ddd;box-sizing:border-box;`
      + `display:flex;align-items:center;justify-content:center;color:#ccc;">`
      + "존재하지 않는 이미지입니다.</div>";

    component.replaceWith(
      `<div class="naver-protected">${store.add(html)}</div>`
    );
  }
}

function protectImages($, root, store) {
  const components = root.find(".se-component.se-image").toArray();

  for (const element of components) {
    const component = $(element);
    const images = component.find("img").toArray();

    if (!images.length) continue;

    const parts = [];

    for (const imageElement of images) {
      const markdown = makeImageMarkdown($(imageElement));

      if (markdown) parts.push(markdown);
    }

    if (!parts.length) continue;

    component.replaceWith(`<div class="naver-protected">${store.add(parts.join("\n\n"))}</div>`);
  }
}

function protectStandaloneImages($, root, store) {
  root.find("img").each((_, element) => {
    const image = $(element);

    if (image.closest(".naver-protected,.naver-protected-inline").length) return;

    const markdown = makeImageMarkdown(image);
    if (!markdown) return;

    image.replaceWith(`<div class="naver-protected">${store.add(markdown)}</div>`);
  });
}

function protectOgCards($, root, store) {
  const components = root.find(".se-component.se-oglink,.og").toArray();

  for (const element of components) {
    const component = $(element);
    const legacy = component.hasClass("og");
    const link = component.find("a[href]").first();

    if (!link.length) continue;

    const href = link.attr("href") || "";
    const title = legacy
      ? component.find(".tit").first().text().trim() || link.attr("title") || href
      : component.find(".se-oglink-title").first().text().trim() || link.attr("title") || href;
    const summary = legacy
      ? component.find(".dsc").first().text().trim()
      : component.find(".se-oglink-summary").first().text().trim();
    const domain = legacy
      ? component.find(".cp").first().text().trim()
      : component.find(".se-oglink-url").first().text().trim();

    const image = component.find("img").first();
    const imageFailed = image.attr("data-download-error") === "true";
    const imageSrc = imageFailed ? "" : image.attr("src") || "";
    const isLarge = component.hasClass("se-l-large_image")
      || component.find(".se-l-large_image,.thumb.b_size").length > 0;

    /*
     * 구형 네이버 OG 카드의 원본 CSS 폭만 보존한다.
     * 높이와 float 등 원본 레이아웃 속성은 적용하지 않는다.
     *
     * .og / .box / .b_size = 513px
     * .s_size = 136px
     */
    const legacyThumb = legacy ? component.find(".thumb").first() : null;
    const cardWidth = legacy ? 513 : 450;
    const thumbWidth = legacy && legacyThumb?.hasClass("s_size") ? 136 : cardWidth;

    const text = [
      title ? `<strong style="font-size:14px;">${escapeHtmlText(title)}</strong>` : "",
      summary ? `<span style="font-size:11px;">${escapeHtmlText(summary)}</span>` : "",
      domain
        ? `<span style="font-size:11px;color:#03c75a;">${escapeHtmlText(domain)}</span>`
        : "",
    ].filter(Boolean).join("<br>");

    const textHtml =
      `<div style="padding:14px 16px;box-sizing:border-box;color:#222;">${text}</div>`;
    let imageHtml = "";

    if (imageSrc) {
      imageHtml = isLarge
        ? `<img src="${escapeHtmlAttribute(imageSrc)}" style="display:block;width:100%;max-width:${thumbWidth}px;">`
        : legacy
          ? `<img src="${escapeHtmlAttribute(imageSrc)}" style="display:block;width:100%;max-width:${thumbWidth}px;">`
          : `<img src="${escapeHtmlAttribute(imageSrc)}" width="120">`;
    } else if (imageFailed) {
      imageHtml = isLarge
        ? `<div style="width:100%;aspect-ratio:513/268;display:flex;align-items:center;justify-content:center;background:#f5f5f5;color:#999;">이미지를 불러올 수 없습니다.</div>`
        : `<div style="width:120px;height:120px;flex:0 0 120px;display:flex;align-items:center;justify-content:center;background:#f5f5f5;color:#999;text-align:center;">이미지를 불러올 수 없습니다.</div>`;
    }

    const linkHtml = isLarge
      ? `<a href="${escapeHtmlAttribute(href)}" style="display:block;color:inherit;text-decoration:none;">${imageHtml}${textHtml}</a>`
      : `<a href="${escapeHtmlAttribute(href)}" style="display:flex;align-items:center;color:inherit;text-decoration:none;">${imageHtml}${textHtml}</a>`;

    const html = isLarge
      ? `<div class="naver-og-card-large" style="width:100%;max-width:${cardWidth}px;background:#fff;border:1px solid #ddd;box-sizing:border-box;">${linkHtml}</div>`
      : `<div style="width:100%;max-width:${cardWidth}px;background:#fff;border:1px solid #ddd;box-sizing:border-box;">${linkHtml}</div>`;

    component.replaceWith(
      `<div class="naver-protected">${store.add(html)}</div>`
    );
  }
}

function escapeHtmlText(value) {
  return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function escapeHtmlAttribute(value) {
  return escapeHtmlText(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function removeArchiveOnlyElements(root) {
  root.find("script, style").remove();
  root.find(".post-top,.post_footer_contents,.bottom_adpost,.post-btn").remove();
}

function isForeignFormattedBlock($, element) {
  const node = $(element);
  const tagName = String(element.tagName || "").toLowerCase();
  const className = node.attr("class") || "";
  const style = node.attr("style") || "";

  // 네이버 구형 에디터 본문은 외부 서식 블록이 아니다.
  if (node.hasClass("view")) return false;

  if (tagName === "pre") return true;

  if (!/^(?:div|section|article|aside)$/i.test(tagName)) return false;

  if (/\b(?:hljs|highlight|codehilite|syntaxhighlighter|prettyprint)\b/i.test(className)) return true;
  if (/\blanguage-[\w-]+\b/i.test(className)) return true;
  if (/\bwhite-space\s*:\s*pre(?:-wrap)?\b/i.test(style)) return true;

  const hasComplexBoxStyle = (
    /(?:background(?:-color)?|border|display\s*:\s*(?:flex|grid)|font-family)\s*:/i.test(style)
  );

  const styledChildren = node.find("[style]").length;

  return hasComplexBoxStyle && styledChildren >= 2;
}

function protectLegacyPastedHtml($, root, store, editorVersion) {
  if (editorVersion !== 1 && editorVersion !== 2) return;

  /*
   * SmartEditor 1/2의 실제 본문 .view를 우선한다.
   *
   * .view 자체에 font-size / font-family 같은 기본 스타일이 있어도
   * 이것은 붙여 넣은 HTML이 아니라 네이버의 기본 본문 래퍼다.
   */
  let content = root.find("#postViewArea .view").first();

  if (!content.length) {
    content = root.find(".post-view > .view,.se3_view,.view").first();
  }

  if (!content.length) {
    content = root.find("#postViewArea .post-view,.post-view").first();
  }

  if (!content.length) return;

  /*
   * SmartEditor 1/2의 기본 본문에는 의미 없는 <div> 래퍼가 들어갈 수 있다.
   * 이런 래퍼는 몇 겹이든 보호하지 않고 내부의 일반 <p>가
   * 문단 변환 단계까지 전달되도록 한다.
   *
   * 별도의 속성이나 서식이 있는 블록만 직접 붙여 넣은 HTML로 보고
   * 원본 그대로 보존한다.
   */
  const blocks = content.children("div,section,article,aside").toArray();

  for (const element of blocks) {
    const node = $(element);

    if (!node.parent().length) continue;
    if (node.hasClass("naver-protected")) continue;
    if (node.hasClass("autosourcing-stub-saved")) continue;

    const attributes = element.attribs || {};
    const attributeNames = Object.keys(attributes);

    if (!attributeNames.length) continue;

    const html = $.html(element);
    node.replaceWith(`<div class="naver-protected">${store.add(html)}</div>`);
  }
}

function protectForeignFormattedBlocks($, root, store) {
  const selector = [
    "pre",
    ".hljs",
    ".highlight",
    ".codehilite",
    ".syntaxhighlighter",
    ".prettyprint",
    "[class*='language-']",
    "[style]",
  ].join(", ");

  const candidates = root.find(selector).add(root.filter(selector)).toArray();

  for (const element of candidates) {
    const node = $(element);

    if (!node.parent().length) continue;
    if (node.closest(".naver-protected").length) continue;
    if (!isForeignFormattedBlock($, element)) continue;

    const formattedParent = node.parents().toArray().find(parent => {
      if (parent === root[0]) return false;
      return isForeignFormattedBlock($, parent);
    });

    if (formattedParent) continue;

    const html = $.html(element);
    node.replaceWith(`<div class="naver-protected">${store.add(html)}</div>`);
  }
}

function makeMarkdown(originalHtml, options = {}) {
  const {editorVersion = 0} = options;

  const $ = cheerio.load(originalHtml, { decodeEntities: false });
  const root = getPostRoot($, editorVersion);
  const store = createStore();

  /*
   * original.html은 모든 다운로드와 로컬화가 끝난 canonical source다.
   * 여기서는 네트워크 요청이나 다운로드를 하지 않는다.
   */
  removeArchiveOnlyElements(root);

  /*
   * img 뒤에 같은 줄의 링크가 붙어 있는 인라인 구조는
   * 다른 변환이 DOM을 분리하기 전에 먼저 HTML로 보호한다.
   */
  protectInlineHtmlLinkGroups($, root, store);

  protectAttachments($, root, store);
  protectNaverVideos($, root, store);
  protectYouTube($, root, store);
  protectOgCards($, root, store);
  protectMissingImages($, root, store);
  protectImages($, root, store);
  protectTables($, root, store);
  protectQuotes($, root, store);

  const horizontalLineTypes = protectHorizontalLines($, root, store);

  /*
   * 네이버 고유 코드블록은 Markdown fenced code로 변환한다.
   */
  protectCodeBlocks($, root, store);

  /*
   * SmartEditor 1/2에서 기본 본문 구조가 아닌 직접 삽입 HTML은
   * Markdown으로 풀지 않고 원본 HTML 그대로 보존한다.
   */
  protectLegacyPastedHtml($, root, store, editorVersion);

  /*
   * 외부 에디터나 웹에서 붙여 넣은 복잡한 서식은 HTML로 보존한다.
   */
  protectForeignFormattedBlocks($, root, store);

  protectTextComponents($, root, store, editorVersion);
  protectStandaloneImages($, root, store);

  const turndown = createTurndown();

  let markdown = turndown.turndown(root.html() || "");

  markdown = store.restore(markdown);
  markdown = restoreEmptyLines(markdown);

  /*
   * 모든 placeholder가 실제 Markdown과 HTML로 복구된 다음
   * <br> 묶음 바로 아래에 빈 줄을 보장한다.
   *
   * <br> 개수 자체는 줄이지 않고 원본 개수 그대로 유지한다.
   */
  markdown = normalizeBreakSpacing(markdown);
  markdown = cleanMarkdown(markdown);

  const horizontalLineCss = getHorizontalLineCss(horizontalLineTypes);
  const legacyTableCss = getLegacyTableCss(markdown);

  return `${horizontalLineCss ? `${horizontalLineCss}\n\n` : ""}${legacyTableCss ? `${legacyTableCss}\n\n` : ""}${markdown}\n`;
}

module.exports = {
  makeMarkdown,
};