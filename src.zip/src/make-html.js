const cheerio = require("cheerio");
const {createImageManager, localizeImages} = require("./image");
const {restoreYoutubeVideos, localizeNaverVideos} = require("./video");
const {localizeAttachments} = require("./attachment");
const {download} = require("./downloader");
const {getContentWidths} = require("./content-width");

function normalizeEditorVersion(value) {
  const version = Number(value);
  return [1, 2, 3, 4].includes(version) ? version : 0;
}

function detectEditorVersion($) {
  const html = $.html();
  const socialMatch = $("#socialPluginInfoJson").text().match(/\bsmartEditorVersion["']?\s*:\s*["']?(\d+)["']?/i);
  if (socialMatch) return normalizeEditorVersion(socialMatch[1]);

  const match = html.match(/\bsmartEditorVersion(?:&(?:quot|#034);|["'])?\s*:\s*["']?(\d+)["']?/i);
  if (match) return normalizeEditorVersion(match[1]);

  const baseInfoMatch = html.match(/aPostBaseInfo\s*\[\s*\d+\s*]\s*=\s*["']([^"']+)["']/i);

  if (baseInfoMatch) {
    const version = Number(baseInfoMatch[1].split("|")[7]);
    if (normalizeEditorVersion(version)) return version;
  }

  const editorVersion = $("[data-post-editor-version]").first().attr("data-post-editor-version");
  if (normalizeEditorVersion(editorVersion)) return Number(editorVersion);

  /* 버전 1 */
  if ($("#postViewArea .post-view > .view").length) return 1;

  /* 버전 2 */
  if ($("#postViewArea .post-view,.post-view,.se3_view,.view").length) return 2;

  /* 버전 4 */
  if ($(".wrap_rabbit .se-viewer .se-main-container").length) return 4;

  /* 버전 3 */
  if ($(".se-viewer .se-main-container").length) return 3;

  return 0;
}

function getVersion12PostRoot($) {
  const content = $("#postViewArea,.se3_view,.post-view,.post-view > .view,.view").first();

  if (content.length) {
    const post = content.closest(".post._post_wrap,.post").first();
    if (post.length) return post;
    return content;
  }

  return $(".post._post_wrap,.post").first();
}

function getPostRoot($, editorVersion) {
  /*
   * 버전 1·2:
   * #postViewArea만 빼면 PostView.css의 .post, .post-back, .post-body,
   * .bcc 관련 구조가 끊긴다. 따라서 글 전체 .post 래퍼를 보존한다.
   */
  if (editorVersion === 1 || editorVersion === 2) {
    const version12 = getVersion12PostRoot($);
    if (version12.length) return version12;
  }

  /*
   * 버전 3·4:
   * .se-main-container를 본문으로 사용하고 실제 원본 조상 래퍼는
   * prepareWrapperPath()에서 그대로 복원한다.
   */
  const smartEditor = $(".se-viewer .se-main-container").first();
  if (smartEditor.length) return smartEditor;

  const mainContainer = $(".se-main-container").first();
  if (mainContainer.length) return mainContainer;

  /*
   * 초기 SmartEditor 3:
   * data-post-editor-version="3"이지만 .se-main-container가 아니라
   * .se_doc_viewer와 .__se_component_area 구조를 사용하는 글이 있다.
   *
   * .se_doc_viewer 전체에는 제목, 작성자, 작성일 등의 헤더가 포함되므로
   * 실제 게시글 내용이 들어 있는 컴포넌트 영역만 root로 사용한다.
   */
  if (editorVersion === 3) {
    const contentsStart = $(".se_doc_contents_start").first();

    if (contentsStart.length) {
      const version3 = contentsStart.nextAll(".__se_component_area").first();

      if (version3.length) return version3;
    }
  }

  const version12 = getVersion12PostRoot($);
  if (version12.length) return version12;

  throw new Error("본문 영역을 찾을 수 없습니다.");
}

function getStylesheetInfo($, pattern, filename) {
  let result = null;

  $("link[rel~='stylesheet'][href]").each((_, element) => {
    const href = $(element).attr("href") || "";
    if (!pattern.test(href)) return undefined;

    result = {url: href, filename};
    return false;
  });

  if (result) return result;

  for (const url of $.html().match(/https?:\/\/[^"'\\\s<>]+/gi) || []) {
    const normalized = url.replace(/&amp;/g, "&");
    if (pattern.test(normalized)) return {url: normalized, filename};
  }

  return null;
}

function getLayoutCssInfo($) {
  return getStylesheetInfo(
    $,
    /(?:LayoutTopCommon|PostTopCommon|PostViewCommon|PostListCommon).*\.css/i,
    "blog-layout.css"
  );
}

function getPostViewCssInfo($) {
  return getStylesheetInfo($, /\/PostView-[^/]*\.css/i, "PostView.css");
}

function getViewerCssInfo($, editorVersion) {
  if (editorVersion === 3 || editorVersion === 4) {
    return getStylesheetInfo($, /se\.viewer\.desktop(?:\.min)?\.css/i, "se.viewer.desktop.css");
  }

  if (editorVersion === 1 || editorVersion === 2) return getPostViewCssInfo($);
  return null;
}

function normalizeUrl(url) {
  const value = String(url || "").replace(/&amp;/g, "&").trim();
  return value.startsWith("//") ? `https:${value}` : value;
}

function rewriteCssUrls(css, cssUrl) {
  return String(css).replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (match, quote, value) => {
    const source = String(value).trim();
    if (!source || source.startsWith("data:") || source.startsWith("blob:") || source.startsWith("#")) return match;

    try {
      return `url("${new URL(source, cssUrl)}")`;
    } catch {
      return match;
    }
  });
}

async function downloadCss(info, outputDir, label) {
  if (!info) return "";

  const url = normalizeUrl(info.url);

  try {
    const result = await download(url, {
      outputDir,
      filename: info.filename,
      overwrite: true,
      logLabel: `${label} CSS`,
      headers: {"User-Agent": "Mozilla/5.0", Referer: "https://blog.naver.com/"},
      transform: buffer => rewriteCssUrls(buffer.toString("utf8"), url),
    });

    return result.filename;
  } catch (error) {
    console.warn(`${label} CSS 다운로드 실패: ${error.message}`);
    return "";
  }
}

async function downloadLayoutCss($, outputDir) {
  const info = getLayoutCssInfo($);
  if (!info) return "";
  return downloadCss(info, outputDir, "블로그 레이아웃");
}

async function downloadPostViewCss($, outputDir, editorVersion) {
  if (editorVersion !== 1 && editorVersion !== 2) return "";

  const info = getPostViewCssInfo($);
  if (!info) return "";

  return downloadCss(info, outputDir, "PostView");
}

async function downloadViewerCss($, outputDir, editorVersion) {
  if (editorVersion !== 3 && editorVersion !== 4) return "";

  const info = getViewerCssInfo($, editorVersion);
  if (!info) return "";

  return downloadCss(info, outputDir, `에디터 v${editorVersion}`);
}

function getBodyAttributes($) {
  const attributes = {};

  for (const [name, value] of Object.entries($("body").first().attr() || {})) {
    if (name === "class" || name === "style" || name.startsWith("data-")) attributes[name] = value;
  }

  return attributes;
}

function getElementDescriptor(element) {
  if (!element || element.type !== "tag") return null;

  const attributes = {};

  for (const [name, value] of Object.entries(element.attribs || {})) {
    if (/^on/i.test(name) || name === "contenteditable" || name === "draggable") continue;
    attributes[name] = value;
  }

  return {tagName: element.tagName || element.name || "div", attributes};
}

function prepareWrapperPath(root, editorVersion) {
  const wrappers = [];
  let current = root.parent();

  while (current.length && !current.is("body,html")) {
    if (current.attr("id") === "twocols") {
      current = current.parent();
      continue;
    }

    const descriptor = getElementDescriptor(current.get(0));

    if (descriptor && current.hasClass("post-body")) {
      /*
       * .post-body는 레이아웃용 table이라 width:auto 상태에서는 본문 내용에 따라 폭이 줄어들 수 있다.
       * #content-area의 전체 폭을 유지하지 않으면 SmartEditor 본문 폭도 함께 줄어드므로 100%를 강제한다.
       */
      const style = descriptor.attributes.style || "";
      descriptor.attributes.style = `${style}${style && !style.trim().endsWith(";") ? ";" : ""}width:100%;`;
    }

    if (descriptor) wrappers.unshift(descriptor);
    current = current.parent();
  }

  if (
    (editorVersion === 3 || editorVersion === 4)
    && !wrappers.some(wrapper => String(wrapper.attributes.class || "").split(/\s+/).includes("se-viewer"))
  ) {
    wrappers.push({tagName: "div", attributes: {class: "se-viewer se-theme-default", lang: "ko-KR"}});
  }

  return wrappers;
}

function makeAttributeString(attributes = {}) {
  return Object.entries(attributes).map(([name, value]) => {
    const escaped = String(value).replace(/&/g, "&amp;").replace(/"/g, "&quot;");
    return ` ${name}="${escaped}"`;
  }).join("");
}

function wrapPostBody(body, wrappers) {
  let result = body;

  for (let index = wrappers.length - 1; index >= 0; index--) {
    const wrapper = wrappers[index];
    result = `<${wrapper.tagName}${makeAttributeString(wrapper.attributes)}>${result}</${wrapper.tagName}>`;
  }

  return result;
}

function isNaverGnbCss(css) {
  return /NTS UIT Development Office|sp_gnb_|\.gnb_|#gnb\b|gnb_notice|gnb_svc/i.test(String(css));
}

function getInlineHeadCss($) {
  return $("head style").toArray().map(element => $(element).html() || "").filter(css => {
    return css.trim() && !isNaverGnbCss(css);
  }).join("\n");
}

function getArchiveOverrideCss(editorVersion, containerWidth) {
  if (editorVersion !== 1 && editorVersion !== 2 && editorVersion !== 3 && editorVersion !== 4) return "";

  const rules = [
    `#body{max-width:none;margin:0 auto;}`,
    `#wrapper{max-width:none;margin:0 auto;box-sizing:border-box;}`,
    `#content-area{${containerWidth ? `width:${containerWidth}px;` : ""}display:block;float:none;margin:0 auto;}`,
  ];

  if (editorVersion === 3 || editorVersion === 4) {
    rules.push(`#post-area .bcc>[id^="post-view"].wrap_rabbit{margin:auto;}`);
  }

  return rules.join("");
}

function cleanRuntimeClasses($, root) {
  const runtimeClasses = new Set([
    "__se-component",
    "se-image-loaded",
    "egjs-visible",
    "se-is-progress",
    "se-section-oembed-video",
  ]);

  root.find("*").each((_, element) => {
    const item = $(element);
    const className = item.attr("class");
    if (!className) return;

    const classes = className.split(/\s+/).filter(Boolean).filter(name => !runtimeClasses.has(name));

    if (classes.length) item.attr("class", classes.join(" "));
    else item.removeAttr("class");
  });
}

function cleanArchivedRoot($, root) {
  root.find("script").remove();
  root.find(".post-top,.post_footer_contents,.bottom_adpost,.post-btn").remove();
  root.find("[id^='naverComment_'][id$='_ct']").remove();

  root.find("style").each((_, element) => {
    const style = $(element);
    const text = style.text();
    if (!text.trim() || /__se_module_data|display\s*:\s*none/i.test(text)) style.remove();
  });

  root.find("[contenteditable]").removeAttr("contenteditable");
  root.find("[draggable]").removeAttr("draggable");
  cleanRuntimeClasses($, root);
}

/*
 * original.html에 들어갈 최종 YouTube iframe을 지연 로딩 상태로 바꾼다.
 *
 * restoreYoutubeVideos()가 모든 YouTube를 복원한 뒤 실행하므로
 * YouTube가 어떤 경로로 만들어졌는지와 관계없이 최종 iframe을 처리한다.
 */
function deferYouTubeIframes($, root) {
  root.find("iframe").add(root.filter("iframe")).each((_, element) => {
    const iframe = $(element);
    const src = String(iframe.attr("src") || "").trim();

    if (!/(?:youtube\.com|youtube-nocookie\.com)\/embed\//i.test(src)) {
      return;
    }

    iframe.attr("data-youtube-src", src);
    iframe.removeAttr("src");
    iframe.attr("loading", "lazy");

    const component = iframe.closest(".naver-local-youtube");

    if (component.length) {
      component.addClass("naver-youtube-loading");
    } else {
      iframe.wrap('<div class="naver-local-youtube naver-youtube-loading"></div>');
    }
  });
}

function protectPostBody(html) {
  return {token: "NAVERPOSTBODYPLACEHOLDER00000000END", content: String(html)};
}

function restorePostBody(html, protectedBody) {
  return String(html).replace(protectedBody.token, () => protectedBody.content);
}

function getYouTubeLoaderScript() {
  return `
<script>
(function () {
  function loadYouTubeIframes() {
    var iframes = document.querySelectorAll(
      ".naver-local-youtube iframe[data-youtube-src]"
    );

    iframes.forEach(function (iframe, index) {
      var src = iframe.getAttribute("data-youtube-src");

      if (!src) return;

      window.setTimeout(function () {
        var component = iframe.closest(".naver-local-youtube");

        iframe.addEventListener("load", function () {
          if (component) {
            component.classList.remove("naver-youtube-loading");
          }
        }, {once: true});

        iframe.setAttribute("src", src);
        iframe.removeAttribute("data-youtube-src");
      }, index * 150);
    });
  }

  window.addEventListener("load", function () {
    window.setTimeout(loadYouTubeIframes, 100);
  });
})();
</script>`;
}

async function makeHtml(rawHtml, outputDir, options = {}) {
  const $ = cheerio.load(rawHtml, {decodeEntities: false});
  const editorVersion = options.editorVersion ?? detectEditorVersion($);
  const root = getPostRoot($, editorVersion);
  const bodyAttributes = getBodyAttributes($);
  const inlineHeadCss = getInlineHeadCss($);
  const {containerWidth, contentWidth} = getContentWidths(editorVersion, rawHtml);
  const archiveOverrideCss = getArchiveOverrideCss(editorVersion, containerWidth);
  const previousHtml = String(options.previousHtml || "");
  let previous$ = null;
  let previousRoot = null;

  if (previousHtml) {
    previous$ = cheerio.load(previousHtml, {decodeEntities: false});

    try {
      previousRoot = getPostRoot(previous$, editorVersion);
    } catch {
      previousRoot = previous$("body");
    }
  }

  const imageManager = createImageManager(outputDir);

  const wrappers = prepareWrapperPath(root, editorVersion);
  const layoutCssFilename = await downloadLayoutCss($, outputDir);
  const postViewCssFilename = await downloadPostViewCss($, outputDir, editorVersion);
  const viewerCssFilename = await downloadViewerCss($, outputDir, editorVersion);

  await localizeImages($, root, imageManager, {editorVersion, previous$, previousRoot});
  await localizeNaverVideos($, root, imageManager, {editorVersion, previous$, previousRoot});
  await localizeAttachments($, root, outputDir, {editorVersion, previous$, previousRoot});

  restoreYoutubeVideos($, root);

  /*
   * 반드시 restoreYoutubeVideos() 뒤에서 처리한다.
   * 이 시점이면 복원 가능한 YouTube iframe이 전부 DOM에 존재한다.
   */
  deferYouTubeIframes($, root);

  cleanArchivedRoot($, root);

  const protectedBody = protectPostBody(wrapPostBody($.html(root), wrappers));
  const layoutCssLink = layoutCssFilename ? `<link rel="stylesheet" href="./${layoutCssFilename}">` : "";
  const postViewCssLink = postViewCssFilename ? `<link rel="stylesheet" href="./${postViewCssFilename}">` : "";
  const viewerCssLink = viewerCssFilename ? `<link rel="stylesheet" href="./${viewerCssFilename}">` : "";

  const html = `
    <!doctype html>
    <html lang="ko">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Naver Blog Post</title>

        ${layoutCssLink}
        ${postViewCssLink}
        ${viewerCssLink}

        <style>${inlineHeadCss}</style>
        <style>${archiveOverrideCss}</style>

        <style>
          html,body{margin:0}
          .naver-local-youtube iframe{max-width:100%}

          .naver-youtube-loading{
            position:relative;
          }

          .naver-youtube-loading::after{
            content:"YouTube 로딩 중...";
            position:absolute;
            left:50%;
            top:50%;
            transform:translate(-50%,-50%);
            z-index:1;
            color:#888;
            font-family:Arial,"Noto Sans KR",sans-serif;
            font-size:14px;
            pointer-events:none;
          }
        </style>
      </head>

      <body${makeAttributeString(bodyAttributes)}>
        ${protectedBody.token}

        ${getYouTubeLoaderScript()}
      </body>
    </html>
  `;

  return restorePostBody(html, protectedBody);
}

module.exports = {makeHtml, getPostRoot, detectEditorVersion, getVersion12PostRoot};